fish_arr = ['fish', 'fiiish', 'fiiiiish', 'fiiiish', 'fffish', 'ffiiiiisshh', 'fsh', 'fiiiissshhhhhh']
# => "fiiiissshhhhhh"

# Sluggish Octopus
def sluggish_octopus(fish_arr)
    
end
#Dominant Octopus
class Array
    def merge_sort
        return self if self.length < 2
        mid = self.length/2
        left = self[0...mid].merge_sort
        right = self[mid..-1].merge_sort
        Array.merge(left, right)
    end
    
    def self.merge(left, right)
        merged = []
        until left.empty? || right.empty?
            if left.first.length < right.first.length
                merged << left.shift
            else
                merged << right.shift
            end
        end
        merged.concat(left)
        merged.concat(right)
        merged
    end
end

# Clever Octopus
def clever_octopus(fish_arr)
    longest = ""
    fish_arr.each { |fish| longest = fish if fish.length > longest.length }
    longest
end


# Dancing Octopus
tiles_array = ["up", "right-up", "right", "right-down", "down", "left-down", "left",  "left-up" ]
def dancing_octopus(tiles_array)
end

# Slow Dance
def slow_dance(direction, tiles)
    tiles.each_with_index { |el, i| return i if el == direction }
end
tiles_hash = Hash.new
tiles_array.each_with_index { |el, i| tiles_hash[el] = i }

# Constant Dance!
def constant_dance(direction, tiles)
    tiles[direction]
end

p sluggish_octopus(fish_arr)
p fish_arr.merge_sort
p clever_octopus(fish_arr)
p dancing_octopus(tiles_array)
p slow_dance("down", tiles_array)
p constant_dance("down", tiles_hash)